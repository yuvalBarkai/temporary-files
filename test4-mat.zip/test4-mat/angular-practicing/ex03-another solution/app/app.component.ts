import { Component } from '@angular/core';
import { MinPicComponent } from './min-pic/min-pic.component';
import { PicComponent } from './pic/pic.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'aa';
  selectedPath="e.jpg";
  arr: MinPicComponent[] = [];
  constructor() {
    let p1: MinPicComponent = new MinPicComponent();
    p1.path = "a.jpg";
    this.arr.push(p1);
    p1 = new MinPicComponent();
    p1.path = "b.jpg";
    this.arr.push(p1);
    p1 = new MinPicComponent();
    p1.path = "c.jpg";
    this.arr.push(p1);
    p1 = new MinPicComponent();
    p1.path = "d.jpg";
    this.arr.push(p1);
  }
  selectedPic(path:string){
    this.selectedPath=path;
  }
   index=0;
  t:any;
  changePic(){
   // console.log("i="+this.index);
    //console.log(this.arr);
   // this.selectedPath=this.arr[this.index++% this.arr.length].path;
  //  setInterval(this.fun1, 1000);
 
   this.t=setInterval(()=>{  this.selectedPath=this.arr[this.index++% this.arr.length].path;}, 1000);
  }
  stopChangePic(){
   clearInterval(this.t);

  }
}
