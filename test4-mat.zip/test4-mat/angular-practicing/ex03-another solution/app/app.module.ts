import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { PicComponent } from './pic/pic.component';
import { MinPicComponent } from './min-pic/min-pic.component';

@NgModule({
  declarations: [
    AppComponent,
    PicComponent,
    MinPicComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
