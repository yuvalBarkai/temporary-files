import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'min-pic',
  templateUrl: './min-pic.component.html',
  styleUrls: ['./min-pic.component.css']
})
export class MinPicComponent implements OnInit {
  @Input() path="./assets/e.jpg";

  constructor() { }

  ngOnInit(): void {
  }

}
