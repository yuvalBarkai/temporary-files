import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MinPicComponent } from './min-pic.component';

describe('MinPicComponent', () => {
  let component: MinPicComponent;
  let fixture: ComponentFixture<MinPicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MinPicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MinPicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
