import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'pic',
  templateUrl: './pic.component.html',
  styleUrls: ['./pic.component.css']
})
export class PicComponent implements OnInit {
@Input() path="./assets/e.jpg";

  constructor() { }

  ngOnInit(): void {
  }

}
