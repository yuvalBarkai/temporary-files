import { Component } from '@angular/core';

@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.scss']
})
export class SkillsComponent {
  skillList = ["HTML","CSS","JavaScript","Bootstrap","jQuery","React","TypeScript","Angular"];
}
