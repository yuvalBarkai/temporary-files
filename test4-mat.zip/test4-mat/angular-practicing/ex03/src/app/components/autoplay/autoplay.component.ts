import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-autoplay',
  templateUrl: './autoplay.component.html',
  styleUrls: ['./autoplay.component.scss']
})
export class AutoplayComponent {
  @Output() start: EventEmitter<boolean> = new EventEmitter<boolean>();

  play() {
    this.start.emit(true);
  }
  stop() {
    this.start.emit(false);
  }
}
