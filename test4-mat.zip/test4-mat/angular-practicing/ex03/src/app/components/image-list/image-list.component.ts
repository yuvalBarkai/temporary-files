import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-image-list',
  templateUrl: './image-list.component.html',
  styleUrls: ['./image-list.component.scss']
})
export class ImageListComponent {
  @Input() imageUrlList: string[] = [];
  @Input() selectedImg: number = 0;

  @Output() select: EventEmitter<number> = new EventEmitter<number>()

  click(index: number) {
    if (index == this.selectedImg)
      this.select.emit(-1);
    else
      this.select.emit(index);
  }
}
