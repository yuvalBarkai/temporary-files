import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ImageListComponent } from './components/image-list/image-list.component';
import { ImageDisplayComponent } from './components/image-display/image-display.component';
import { AutoplayComponent } from './components/autoplay/autoplay.component';

@NgModule({
  declarations: [
    AppComponent,
    ImageListComponent,
    ImageDisplayComponent,
    AutoplayComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
