import { Component } from '@angular/core';
import imgList from './imgList';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  imageUrlList = imgList;
  selectedImgIndex = -1;

  interval: NodeJS.Timer | undefined;
  autoplay(start: boolean) {
    if (start)
      this.interval = setInterval(() => {
        if (this.selectedImgIndex + 1 >= this.imageUrlList.length)
          this.selectedImgIndex = 0;
        else
          this.selectedImgIndex++
      }, 1000);
    else
      clearInterval(this.interval);
  }

  selected(imgIndex: number) {
    this.selectedImgIndex = imgIndex;
  }
}
