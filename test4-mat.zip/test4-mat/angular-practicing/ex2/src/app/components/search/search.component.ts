import { Component } from '@angular/core';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent {
  keyWord = "";
  isBusy = false;
  result: string[] = [];

  search() {
    this.isBusy = true;
    setTimeout(() => {
      this.result = [];
      for (let i = 0; i < 10; i++) {
        let rand = Math.floor(Math.random() * 100) + 1;
        this.result.push(`${this.keyWord} -- ${rand}`);
      }
      this.isBusy = false;
    }, 1500);
  }
}
