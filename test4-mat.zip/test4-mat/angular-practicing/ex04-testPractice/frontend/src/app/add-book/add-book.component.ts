import { Component } from '@angular/core';
import { Router } from '@angular/router';

interface part1Type {
  book_name: string;
  author_name: string,
  language_id: number;
}

interface part2Type {
  publish_date: string;
  number_of_pages: number | undefined;
}

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.scss']
})
export class AddBookComponent {
  constructor(
    /* private router: Router, */
  ) { }

  /* part1: part1Type = { book_name: "", author_name: "", language_id: -1 };
  part2: part2Type = { publish_date: "", number_of_pages: undefined }; */
}
