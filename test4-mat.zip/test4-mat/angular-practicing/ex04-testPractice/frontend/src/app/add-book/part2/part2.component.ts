import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-part2',
  templateUrl: './part2.component.html',
  styleUrls: ['./part2.component.scss']
})
export class Part2Component implements OnInit {
  
  constructor(private router: Router) {
    const data = this.router.getCurrentNavigation()?.extras.state;
    console.log(data);
  }

  ngOnInit() {

  }
}
