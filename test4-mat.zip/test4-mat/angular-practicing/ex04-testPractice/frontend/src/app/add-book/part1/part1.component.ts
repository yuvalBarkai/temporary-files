import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { LanguageType } from 'src/app/types';
import { ServerRequestsService } from 'src/services/server-requests.service';

@Component({
  selector: 'app-part1',
  templateUrl: './part1.component.html',
  styleUrls: ['./part1.component.scss']
})
export class Part1Component implements OnInit {
  constructor(
    private ServerRequests: ServerRequestsService,
    private router: Router
  ) { }

  @ViewChild('f') form: HTMLFormElement | undefined;
  part1Form = { book_name: "", author: "", language_id: -1 };
  languages: LanguageType[] = [];

  ngOnInit() {
    this.ServerRequests.getLanguages()
      .subscribe(langList => this.languages = langList);
  }

  toPart2() {
    this.router.navigate(["add/part2"], { state: { data: this.part1Form } });
  }
}
  