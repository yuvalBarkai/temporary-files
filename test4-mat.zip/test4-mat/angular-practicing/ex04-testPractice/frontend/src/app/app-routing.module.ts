import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddBookComponent } from './add-book/add-book.component';
import { Part1Component } from './add-book/part1/part1.component';
import { Part2Component } from './add-book/part2/part2.component';
import { BooksComponent } from './books/books.component';
import { LanguagesComponent } from './languages/languages.component';

const routes: Routes = [
  {
    path: "books",
    component: BooksComponent,
  },
  {
    path: "add",
    component: AddBookComponent,
    children: [
      {
        path: "part1",
        component: Part1Component,
      },
      {
        path: "part2",
        component: Part2Component,
        data: { data: "Test" },
      },
      {
        path: "**",
        redirectTo: "part1",
      }
    ]
  },
  {
    path: "languages",
    component: LanguagesComponent,
  },
  {
    path: "**",
    redirectTo: "books",
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
