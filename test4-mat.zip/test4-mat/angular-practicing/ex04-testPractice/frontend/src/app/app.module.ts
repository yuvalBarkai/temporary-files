import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BooksComponent } from './books/books.component';
import { AddBookComponent } from './add-book/add-book.component';
import { LanguagesComponent } from './languages/languages.component';
import { ServerRequestsService } from 'src/services/server-requests.service';
import { HttpClientModule } from '@angular/common/http';
import { Part1Component } from './add-book/part1/part1.component';
import { Part2Component } from './add-book/part2/part2.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    BooksComponent,
    AddBookComponent,
    LanguagesComponent,
    Part1Component,
    Part2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule,
  ],
  providers: [ServerRequestsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
