import { Component } from '@angular/core';
import { ServerRequestsService } from 'src/services/server-requests.service';
import { BookType } from '../types';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.scss']
})
export class BooksComponent {
  constructor(private ServerRequests: ServerRequestsService) { }
  bookList: BookType[] = [];
  bookListTouched = false;

  ngOnInit() {
    this.updateBooks();
  }

  updateBooks() {
    this.ServerRequests.getAllBooks()
      .subscribe(books => { this.bookList = books; this.bookListTouched = true });
  }
}
