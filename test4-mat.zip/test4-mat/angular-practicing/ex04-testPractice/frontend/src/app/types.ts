export interface BookType {
  book_id?: number;
  book_name: string;
  book_author: string;
  number_of_pages: number;
  publish_date: string;
  language_id: number;
}

export interface LanguageType {
  language_id?: number;
  language_name: string;
}
