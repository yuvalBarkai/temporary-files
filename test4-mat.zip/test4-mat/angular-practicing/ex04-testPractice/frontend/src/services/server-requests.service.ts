import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BookType, LanguageType } from 'src/app/types';

@Injectable()
export class ServerRequestsService {
  private BASE_URL = "http://localhost:6060/api";

  constructor(private http: HttpClient) { }

  getAllBooks(): Observable<BookType[]> {
    return this.http.get<BookType[]>(`${this.BASE_URL}/books`);
  }

  getLanguages(): Observable<LanguageType[]> {
    return this.http.get<LanguageType[]>(`${this.BASE_URL}/languages`);
  }

  addBook(newBook: BookType): Observable<Object> {
    return this.http.post(`${this.BASE_URL}/books`, newBook);
  }

  addLanguage(newLang: LanguageType) {
    return this.http.post(`${this.BASE_URL}/languages`, newLang);
  }

  removeLanguage(langId: number) {
    return this.http.delete(`${this.BASE_URL}/languages/${langId}`);
  }

  editLanguage(langId: number, newName: string) {
    return this.http.patch(`${this.BASE_URL}/languages/${langId}`, { language_name: newName });
  }
}
