const express = require("express")
const cors = require("cors")
const config = require("./configuration.json");
const booksController = require("./controllers/books-controller");
const languagesController = require("./controllers/languages-controller");

const server = express();
server.use(cors());
server.use(express.json());

server.use("/api/books", booksController);
server.use("/api/languages", languagesController);

server.use("*", (req, res) => {
    res.send(`Not Found: ${req.originalUrl}`);
});

server.listen(config.serverPort, () => {
    console.log(`Listening at ${config.serverPort}`);
}).on("error", err => {
    if (err.code == "EADDRINUSE") {
        console.log(`Port ${config.serverPort} is taken`);
    }
    else {
        console.log(`Unknown Error`);
    }
});
