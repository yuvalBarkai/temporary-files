const mySQL = require("mysql");
const config = require("../configuration.json");

const pool = mySQL.createPool({
    host: config.dbHost,
    port: config.dbPort,
    database: config.dbName,
    user: config.dbUser,
});

function executeQueryAsync(sqlCmd) {
    return new Promise((resolve, reject) => {
        pool.query(sqlCmd, (err, result) => {
            if (err)
                reject(err);
            else
                resolve(result);
        });
    });
}

module.exports = { executeQueryAsync };