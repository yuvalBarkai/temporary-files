const dal = require("../data-access/dal");

function selectAllBooksAsync() {
    return dal.executeQueryAsync("SELECT * FROM books");
}

function selectBookByIdAsync(bookId) {
    return dal.executeQueryAsync(`SELECT * FROM books WHERE book_id = "${bookId}"`);
}

function deleteBookByIdAsync(bookId) {
    return dal.executeQueryAsync(`DELETE FROM books WHERE book_id = "${bookId}"`);
}

function insertBookAsync(newBook) {
    return dal.executeQueryAsync(`INSERT INTO books (book_name, author, number_of_pages, publish_date, language_id) VALUES("${newBook.book_name}","${newBook.author}","${newBook.number_of_pages}")`);
}


module.exports = {
    selectAllBooksAsync,
    selectBookByIdAsync,
    deleteBookByIdAsync,
    insertBookAsync,
}