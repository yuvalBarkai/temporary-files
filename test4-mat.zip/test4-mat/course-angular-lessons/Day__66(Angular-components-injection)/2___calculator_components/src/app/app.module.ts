import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { AddExerciseComponent } from './add-exercise/add-exercise.component';
import { EditExerciseComponent } from './edit-exercise/edit-exercise.component';
import { DeleteExerciseComponent } from './components/delete-exercise/delete-exercise.component';
import { AboutComponent } from './components/home-area/about/about.component';

@NgModule({
  declarations: [
    AppComponent,
    AddExerciseComponent,
    EditExerciseComponent,
    DeleteExerciseComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
