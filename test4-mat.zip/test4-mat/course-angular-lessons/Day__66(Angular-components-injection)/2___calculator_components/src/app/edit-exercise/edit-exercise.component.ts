import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-exercise',
  templateUrl: './edit-exercise.component.html',
  styleUrls: ['./edit-exercise.component.css']
})
export class EditExerciseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
