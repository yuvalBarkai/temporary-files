import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-exercise',
  templateUrl: './delete-exercise.component.html',
  styleUrls: ['./delete-exercise.component.css']
})
export class DeleteExerciseComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
