﻿import { Component, Output, EventEmitter } from '@angular/core';

import { Hero } from '../hero';

@Component({
    selector: 'add-hero',
    template: `
    <h2>Add Hero</h2>
    <input [(ngModel)]="newHero.id" placeholder="id" />
    <input [(ngModel)]="newHero.name" placeholder="name" />
    <input type="button" [disabled]="!newHero.id || !newHero.name" (click)="add()" value="Add"/>
  `
})
export class AddHeroComponent {
    @Output() adding: EventEmitter<Hero> = new EventEmitter<Hero>();

    newHero: Hero = new Hero();

    add(): void {
        this.adding.emit(this.newHero);
        this.newHero = new Hero();
    }
}
