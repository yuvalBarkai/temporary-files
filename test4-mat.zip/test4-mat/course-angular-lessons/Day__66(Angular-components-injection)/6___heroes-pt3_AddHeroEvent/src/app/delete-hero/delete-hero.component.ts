import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-delete-hero',
  templateUrl: './delete-hero.component.html',
  styleUrls: ['./delete-hero.component.css']
})
export class DeleteHeroComponent {
  @Input() selectedHero: number;

  cancel() {
    console.log("cancel");
  }
  deleteHero(){
    console.log("delete");
  }
}
