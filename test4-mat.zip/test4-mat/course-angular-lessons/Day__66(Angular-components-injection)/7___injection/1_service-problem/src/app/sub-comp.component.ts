﻿import { Component } from '@angular/core';
import { DataService } from './data.service';

@Component({
    selector: 'sub-comp',
    template: `
    <h2>Sub Comp</h2>
    <p>
        <input type="button" value="Get rate" (click)="getRate()" />
    </p>
    <p>
        {{dollarRate}}
    </p>
  `
})
export class SubCompComponent {
    data = new DataService();
    dollarRate: number;

    getRate(): void {
        this.dollarRate = this.data.getDollarRate();
    }
}
