﻿export class DataService {
    private rates: number[] = [3.50, 3.40, 3.65];
    private index = 0;

    getDollarRate(): number
    {
        let rate = this.rates[this.index];
        this.index++;
        if (this.index >= this.rates.length)
            this.index = 0;
        return rate;
    }
}