import { Component } from '@angular/core';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  template: `
    <h1>Hello Services</h1>
    <p>
        <input type="button" value="Get rate" (click)="getRate()" />
    </p>
    <p>
        {{dollarRate}}
    </p>
    <sub-comp></sub-comp>
  `
})
export class AppComponent {
    data = new DataService();
    dollarRate: number;

    getRate(): void {
        this.dollarRate = this.data.getDollarRate();
    }
}
