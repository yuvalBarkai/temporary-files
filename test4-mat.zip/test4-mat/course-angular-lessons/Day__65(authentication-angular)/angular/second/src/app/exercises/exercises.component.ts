import { Component } from '@angular/core';

@Component({
  selector: 'app-exercises',
  templateUrl: './exercises.component.html',
  styleUrls: ['./exercises.component.css']
})
export class ExercisesComponent {
  title = "SubComp";
  first = 1;
  second = 2;
  result = 3;

  add() {
    this.result = this.first + this.second;
  }
  divide() {
    this.result = this.first / this.second;
  }
  multiply() {
    this.result = this.first * this.second;
  }
  sqrt() {
    this.result = Math.sqrt(this.first);
  }
}
