import { Component, SyntheticEvent } from "react";
import ChatService from "../../Services/chat-service";
import "./ChatView.css";


interface ChatViewState {
    nickname: string;
    message: string;
    allMessages: string[];
}

class ChatView extends Component<{}, ChatViewState> {

    private chatService = new ChatService();

    constructor(props: {}) {
        super(props);
        this.state = { nickname: "", message: "", allMessages: [] };
    }

    public render(): JSX.Element {
        return (
            <div className="ChatView">
                <h2>Chat with socket.io</h2>

                <button onClick={this.connect}>Connect</button>
                <button onClick={this.disconnect}>Disconnect</button>
                <p>
                    <label>Nick name: </label> <br></br>
                    <input onChange={this.nicknameChanged} value={this.state.nickname} />
                </p>
                <p>
                    <label>Message:</label> <br></br>
                    <input onChange={this.messageChanged} value={this.state.message} />
                </p>
                <button onClick={this.send}>Send</button>
                <div>
                    {this.state.allMessages.map((message, index) => 
                        <div key={index}> {message} </div>)}
                </div>
            </div>
        );
    }

    connect = () => {
        this.chatService.connect();
        this.chatService.socket?.on("msg-from-server", message => {
            const messages=[...this.state.allMessages];
            messages.push(message);
            this.setState({allMessages:messages})
        })
    }

    disconnect = () => {
        this.chatService.disconnect();
    }

    send = () => {
        this.chatService.send(`${this.state.nickname}: ${this.state.message}`);
        this.setState({message:"" });
    }

    nicknameChanged = (e: SyntheticEvent) => {
        const nickname = (e.target as HTMLInputElement).value;
        this.setState({ nickname });
    }

    messageChanged = (e: SyntheticEvent) => {
        const message = (e.target as HTMLInputElement).value;
        this.setState({ message });
    }
}

export default ChatView;
