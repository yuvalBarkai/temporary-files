import './App.css';
import ChatView from './Components/ChatView/ChatView';

function App() {
    return (
        <div className="App">
            <h1>React Basic Template</h1>
            <ChatView />
        </div>
    );
}

export default App;
