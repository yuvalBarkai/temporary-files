const { builtinModules } = require("module");
const io=require("socket.io");

let socketsManager;

function init(listener) {
    socketsManager=io(listener, {cors: {origin: "http://localhost:3000"}});

    socketsManager.sockets.on("connection", socket => {
        console.log("A client is connected ");

        socket.on("disconnect", (reason) => {
            console.log("A client is disconnected ");
        });

        socket.on("msg-from-client", message => {
            socketsManager.sockets.emit("msg-from-server", message);
        });
    });
}

module.exports = {
    init
}