const express=require("express");
const chatLogic=require("./chat-logic");
const app=express();
const listener=app.listen(4005, ()=>console.log("listening on 4005"));
chatLogic.init(listener);