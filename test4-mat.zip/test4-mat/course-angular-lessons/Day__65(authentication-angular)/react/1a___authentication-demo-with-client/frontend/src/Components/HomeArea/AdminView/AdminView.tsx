import { Component } from "react";
import jwtAxios from "../../../Services/JwtAxios";
import "./AdminView.css";

interface AdminViewState {
    message: string;
}

class AdminView extends Component<{}, AdminViewState> {
    constructor(props:{}) {
        super(props);
        this.state={message:""}
    }

    componentDidMount = async () => {
        try {
            const response = await jwtAxios.get<string>("http://localhost:4000/admin");
            this.setState({ message: response.data });
        } catch (error) {
            alert("AdminView: " + error);
        }
    };

    public render(): JSX.Element {
        return (
            <div className="AdminView">
				<div>
                    <span>{this.state.message}</span>
                </div>
            </div>
        );
    }
}

export default AdminView;
