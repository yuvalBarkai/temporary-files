import './App.css';
import LoginView from './Components/AuthArea/LoginView/LoginView';
import AdminView from './Components/HomeArea/AdminView/AdminView';
import MediumView from './Components/HomeArea/MediumView/MediumView';
import PublicView from './Components/HomeArea/PublicView/PublicView';

function App() {
    return (
        <div className="App">
            <h1>JWT Client</h1>
            <LoginView />
            <PublicView />
            <MediumView />
            <AdminView />
        </div>
    );
}

export default App;
