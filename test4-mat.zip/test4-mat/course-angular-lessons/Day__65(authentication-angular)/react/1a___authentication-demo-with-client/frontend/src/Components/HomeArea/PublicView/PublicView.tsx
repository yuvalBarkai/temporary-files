import axios from "axios";
import { Component } from "react";
import "./PublicView.css";

interface PublicViewState {
    message:string;
}

class PublicView extends Component<{}, PublicViewState> {

    constructor(props:{}) {
        super(props);
        this.state={message:""}
    }

    componentDidMount = async () => {
        const response=await axios.get<string>("http://localhost:4000/public");
        this.setState({message: response.data});
    };

    public render(): JSX.Element {
        return (
            <div className="PublicView">
				<span>{this.state.message}</span>
            </div>
        );
    }
}

export default PublicView;
