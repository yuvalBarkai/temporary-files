const express = require("express");

// const productsLogic = require("../business-logic-layer/entity-logic");

const router = express.Router();

router.get("/", async (request, response) => {
    try {
        // const response=await ...
        response.send("OK - Public");
    }
    catch (error) {
        response.status(500).send(error);
    }
});

module.exports = router;