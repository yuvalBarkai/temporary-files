const express = require("express");
const fs = require("fs");
const path = require("path");
const fileUpload = require("express-fileupload");


// const detailsLogic = require("../business-logic-layer/details-logic");

const router = express.Router();
router.use(fileUpload());


router.post("/post", async (request, response) => {
    try {
        const name = request.body.name;
        const image = request.files.image;
        const absolutePath = path.join(__dirname, "..", "images", image.name);
        await image.mv(absolutePath);   // mv = move
        console.log(absolutePath);
        response.send("OK");
    }
    catch (error) {
        response.status(500).send(error);
    }
});

router.get("/images/:imageName", (request, response) => {
    try {
        // Data: 
        const imageName = request.params.imageName;

        // Logic: 
        let imageFile = path.join(__dirname, "../images", imageName);
        if (!fs.existsSync(imageFile)) imageFile = locations.notFoundImageFile;

        // Success: 
        response.sendFile(imageFile);
    }
    catch (err) {
        response.status(500).send(err.message);
    }
});

module.exports = router;