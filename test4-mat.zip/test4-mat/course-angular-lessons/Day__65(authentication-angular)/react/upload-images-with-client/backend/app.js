const express = require("express");
const cors = require("cors");
const fileUpload=require("express-fileupload");

const detailsController=require("./controllers-layer/details-controller");

const server = express();
server.use(cors());
server.use(express.json());
// server.use(fileUpload());

server.use("/", detailsController);

server.use("*", (req, res) => {
    res.status(404).send(`Route not found ${req.originalUrl}`);
});

server.listen(4000, () => {
    console.log("Listening on 4000");
}).on("error", (err) => {
    if (err.code === "EADDRINUSE")
        console.log("Error: Address in use");
    else 
        console.log("Error: Unknown error");
});