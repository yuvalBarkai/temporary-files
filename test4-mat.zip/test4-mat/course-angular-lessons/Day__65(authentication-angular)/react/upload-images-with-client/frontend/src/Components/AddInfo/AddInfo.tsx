import axios from "axios";
import { Component, SyntheticEvent } from "react";
import "./AddInfo.css";

interface AddInfoState {
    name: string;
    image: any;
}

class AddInfo extends Component<{}, AddInfoState> {

    constructor(props:{}) {
        super(props);
        this.state={name: "", image:""};
    }

    public render(): JSX.Element {
        return (
            <div className="AddInfo">
                <h2>Add Info</h2>
                <p>
                    <span>Name:</span><br />
                    <input onChange={this.nameChanged} />
                </p>
                <p>
                    <span>Image:</span><br />
                    <input type="file" name="myImage" onChange={this.imageChanged} multiple />
                </p>
                <p>
                    <button onClick={this.send}>Send</button> 
                </p>
            </div>
        );
    }

    private nameChanged = (e: SyntheticEvent) => {
        const name=(e.target as HTMLInputElement).value
        this.setState({name:name});
    }

    private imageChanged=(e: SyntheticEvent) => {
        const image=(e.target as HTMLInputElement).files;
        this.setState({image:image});
    }

    private send = async (e: SyntheticEvent) => {
        const myFormData = new FormData();
        myFormData.append("name", this.state.name);
        myFormData.append("image", this.state.image[0]);
        const response= await axios.post("http://localhost:4000/post", myFormData);
        alert(response.data);
    }
}

export default AddInfo;
