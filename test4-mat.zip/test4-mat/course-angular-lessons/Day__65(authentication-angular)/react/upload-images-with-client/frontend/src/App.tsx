import './App.css';
import AddInfo from './Components/AddInfo/AddInfo';
import ServerImages from './Components/ServerImages/ServerImages';

function App() {
    return (
        <div className="App">
            <h1>Images</h1>
            <AddInfo />
            <ServerImages />
        </div>
    );
}

export default App;
