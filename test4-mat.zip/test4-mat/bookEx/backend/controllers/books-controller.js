const express = require("express");
const router = express.Router();
const booksLogic = require("../bussiness/books-logic");

router.get("/", async (req, res) => {
    try {
        const result = await booksLogic.selectAllBooksAsync();
        res.send(result);
    } catch (error) {
        console.log(error);
        res.status(500).send({ message: "Server Error" });
    }
});

router.get("/:id", async (req, res) => {
    const id = req.params.id;
    if (isNaN(id))
        res.status(400).send({ message: `Incorrect book id: ${id}` });
    else {
        try {
            const book = await booksLogic.selectBookByIdAsync(id);
            if (book?.length >= 1)
                res.send(book[0]);
            else
                res.status(404).send({ message: `Book number ${id} was not found` });
        }
        catch (error) {
            console.log(error);
            res.status(500).send({ message: "Server Error" });
        }
    }
});

router.delete("/:id", async (req, res) => {
    const id = req.params.id;
    if (isNaN(id))
        res.status(400).send({ message: `Incorrect book id: ${id}` });
    else {
        try {
            const result = await booksLogic.deleteBookByIdAsync(id);
            res.send(result);
            // trying to delete a not found book is not an error
            // and it will be found in result.affectedRows;
        }
        catch (error) {
            console.log(error);
            res.status(500).send({ message: "Server Error" });
        }
    }
});

router.post("/", async (req, res) => {
    try {
        const newBook = req.body;
        // validation
        const result = await booksLogic.insertBookAsync(newBook);
        res.send(result);
    } catch (error) {
        console.log(error);
        res.status(500).send({ message: "Server Error" });
    }
});

module.exports = router;