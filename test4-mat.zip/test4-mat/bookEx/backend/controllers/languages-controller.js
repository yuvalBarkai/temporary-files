const express = require("express");
const router = express.Router();
const languagesLogic = require("../bussiness/languages-logic")

router.get("/", async (req, res) => {
    try {
        const result = await languagesLogic.selectAllLanguagesAsync();
        res.send(result);
    } catch (error) {
        console.log(error);
        res.status(500).send({ message: "Server Error" });
    }
});

router.get("/:id", async (req, res) => {
    const id = req.params.id;
    if (isNaN(id))
        res.status(400).send({ message: `Incorrect book id: ${id}` });
    else {
        try {
            const language = await languagesLogic.selectLanguageByIdAsync(id);
            if (language?.length >= 1)
                res.send(language[0]);
            else
                res.status(404).send({ message: `Book number ${id} was not found` });

        }
        catch (error) {
            console.log(error);
            res.status(500).send({ message: "Server Error" });
        }
    }
});

router.delete("/:id", async (req, res) => {
    const id = req.params.id;
    if (isNaN(id))
        res.status(400).send({ message: `Incorrect book id: ${id}` });
    else {
        try {
            const result = await languagesLogic.deleteLanguageByIdAsync(id);
            res.send(result);
        }
        catch (error) {
            console.log(error);
            res.status(500).send({ message: "Server Error" });
        }
    }
});

router.post("/", async (req, res) => {
    try {
        const newLanguage = req.body.language_name;
        // validation
        const result = await languagesLogic.insertLanguageAsync(newLanguage);
        res.send(result);
    } catch (error) {
        console.log(error);
        res.status(500).send({ message: "Server Error" });
    }
});

router.patch("/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const newName = req.body.language_name;
        if (!newName)
            res.status(400).send({ message: "language_name is missing" });
        else {
            const result = await languagesLogic.updateLanguageAsync(id, newName);
            res.send(result);
        }
    } catch (error) {
        console.log(error);
        res.status(500).send({ message: "Server Error" });
    }
});

module.exports = router;