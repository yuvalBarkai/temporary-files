const dal = require("../data-access/dal");

function selectAllBooksAsync() {
    return dal.executeQueryAsync(`
    SELECT book_name, author, number_of_pages, publish_date, language_name
    FROM books 
    LEFT JOIN languages
    ON books.language_id = languages.language_id
    `);
}

function selectBookByIdAsync(bookId) {
    return dal.executeQueryAsync(`
    SELECT book_name, author, number_of_pages, publish_date, language_name
    FROM books 
    LEFT JOIN languages
    ON books.language_id = languages.language_id
    WHERE book_id = "${bookId}"
    `);
}

function deleteBookByIdAsync(bookId) {
    return dal.executeQueryAsync(`DELETE FROM books WHERE book_id = "${bookId}"`);
}

function insertBookAsync(newBook) {
    return dal.executeQueryAsync(`INSERT INTO books (book_name, author, number_of_pages, publish_date, language_id) VALUES("${newBook.book_name}","${newBook.author}","${newBook.number_of_pages}","${newBook.publish_date}","${newBook.language_id}")`);
}


module.exports = {
    selectAllBooksAsync,
    selectBookByIdAsync,
    deleteBookByIdAsync,
    insertBookAsync,
}