const dal = require("../data-access/dal");

function selectAllLanguagesAsync() {
    return dal.executeQueryAsync("SELECT * FROM languages");
}

function selectLanguageByIdAsync(languageId) {
    return dal.executeQueryAsync(`SELECT * FROM languages WHERE language_id = "${languageId}"`);
}

function insertLanguageAsync(newLanguage) {
    return dal.executeQueryAsync(`INSERT INTO languages (language_name) VALUES("${newLanguage}")`);
}

function updateLanguageAsync(languageId, newName) {
    return dal.executeQueryAsync(`UPDATE languages SET language_name = "${newName}" WHERE language_id = "${languageId}"`);
}

function deleteLanguageByIdAsync(languageId) {
    return dal.executeQueryAsync(`DELETE FROM languages WHERE language_id = "${languageId}"`)
}

module.exports = {
    selectAllLanguagesAsync,
    selectLanguageByIdAsync,
    insertLanguageAsync,
    updateLanguageAsync,
    deleteLanguageByIdAsync
};