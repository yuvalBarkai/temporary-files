import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { bookType, languageType } from '../types';

@Injectable()
export class ServerRequestsService {
  constructor(private http: HttpClient) { }

  private BASE_URL = "http://localhost:6060/api";

  getBooks(): Observable<bookType[]> {
    return this.http.get<bookType[]>(`${this.BASE_URL}/books`);
  }

  postBook(newBook: bookType) {
    return this.http.post(`${this.BASE_URL}/books`, newBook);
  }

  getLanguages(): Observable<languageType[]> {
    return this.http.get<languageType[]>(`${this.BASE_URL}/languages`);
  }

  deleteLanguage(langId: number) {
    return this.http.delete(`${this.BASE_URL}/languages/${langId}`);
  }

  patchLanguage(langId: number, newName: string) {
    return this.http.patch(`${this.BASE_URL}/languages/${langId}`, { language_name: newName });
  }
}
