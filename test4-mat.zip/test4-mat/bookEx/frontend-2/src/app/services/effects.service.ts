import { EventEmitter, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EffectsService {

  colorEvent = new EventEmitter();

  emitColorHeader(){
    this.colorEvent.emit();
  }
}
