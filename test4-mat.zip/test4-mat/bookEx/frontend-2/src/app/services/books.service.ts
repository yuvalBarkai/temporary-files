import { EventEmitter, Injectable } from '@angular/core';
import { bookType } from '../types';

@Injectable({
  providedIn: 'root'
})
export class BooksService {
  sentBooks = new EventEmitter<bookType[]>();

  emitBooks(books: bookType[]) {
    this.sentBooks.emit(books);
  }
}
