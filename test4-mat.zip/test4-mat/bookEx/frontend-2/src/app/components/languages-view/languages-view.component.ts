import { Component, EventEmitter, OnInit, Output, ViewChild, ViewChildren } from '@angular/core';
import { finalize } from 'rxjs';
import { BooksService } from 'src/app/services/books.service';
import { EffectsService } from 'src/app/services/effects.service';
import { ServerRequestsService } from 'src/app/services/server-requests.service';
import { bookType, languageType } from 'src/app/types';

@Component({
  selector: 'app-languages-view',
  templateUrl: './languages-view.component.html',
  styleUrls: ['./languages-view.component.scss']
})
export class LanguagesViewComponent implements OnInit {
  constructor(private ServerRequests: ServerRequestsService, private effect: EffectsService, private booksService: BooksService) { }

  languageList: languageType[] = [];

  langIdToEdit: number = -1;
  langNewName: string = "";

  ngOnInit() {
    this.updateList();
  }

  updateList() {
    this.ServerRequests.getLanguages()
      .subscribe({
        next: langList => {
          this.languageList = langList;
        },
        error: (err) => {
          console.log(err);
        }
      });
  }

  remove(langId: number | undefined) {
    if (langId)
      this.ServerRequests.deleteLanguage(langId)
        .subscribe(res => { console.log(res); this.updateList() });
  }

  edit(langId: number | undefined) {
    this.effect.emitColorHeader();
    if (langId) {
      if (this.langIdToEdit == langId) {
        this.ServerRequests.patchLanguage(langId, this.langNewName)
          .pipe(finalize(() => {
            this.langIdToEdit = -1;
            this.langNewName = "";
          })).subscribe({
            next: res => {
              console.log(res);
              this.updateList();
            },
            error: (err) => {
              if (err.status == 400)
                alert("Language name was not changed");
              else
                console.log(err);
            }
          });
      }
      else
        this.langIdToEdit = langId;
    }
  }
}
