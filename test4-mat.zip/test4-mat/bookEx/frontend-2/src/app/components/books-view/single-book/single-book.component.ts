import { Component, Input } from '@angular/core';
import { bookType } from 'src/app/types';

@Component({
  selector: 'app-single-book',
  templateUrl: './single-book.component.html',
  styleUrls: ['./single-book.component.scss']
})
export class SingleBookComponent {
  @Input() book: bookType | undefined;
}
