import { Component, OnInit } from '@angular/core';
import { BooksService } from 'src/app/services/books.service';
import { ServerRequestsService } from 'src/app/services/server-requests.service';
import { bookType } from 'src/app/types';

@Component({
  selector: 'app-books-view',
  templateUrl: './books-view.component.html',
  styleUrls: ['./books-view.component.scss']
})
export class BooksViewComponent implements OnInit {
  constructor(private ServerRequests: ServerRequestsService, private BooksService:BooksService) { }

  bookList: bookType[] = [];

  ngOnInit() {
    this.ServerRequests.getBooks()
      .subscribe(books => {
        this.bookList = books;
        this.BooksService.emitBooks(books);
      });
  }
}
