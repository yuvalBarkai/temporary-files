import { Component, OnInit, ViewChild } from '@angular/core';
import { EffectsService } from './services/effects.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  constructor(private effects: EffectsService) { }
  ngOnInit() {
    this.effects.colorEvent.subscribe(()=>{this.colorHeader()});
  }
  color = "black";
  colorHeader() {
    this.color = "cyan";
    const timer = setTimeout(() => {
      this.color = "black";
      clearTimeout(timer);
    }, 2000)
  }
}
