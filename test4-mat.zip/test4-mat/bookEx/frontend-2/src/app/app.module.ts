import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BooksViewComponent } from './components/books-view/books-view.component';
import { AddBookComponent } from './components/add-book/add-book.component';
import { LanguagesViewComponent } from './components/languages-view/languages-view.component';
import { HttpClientModule } from '@angular/common/http';
import { ServerRequestsService } from './services/server-requests.service';
import { FormsModule } from '@angular/forms';
import { SingleBookComponent } from './components/books-view/single-book/single-book.component';

@NgModule({
  declarations: [
    AppComponent,
    BooksViewComponent,
    AddBookComponent,
    LanguagesViewComponent,
    SingleBookComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [ServerRequestsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
