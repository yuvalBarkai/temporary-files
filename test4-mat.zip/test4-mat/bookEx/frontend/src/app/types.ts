export interface bookType {
  book_id?: number;
  book_name: string;
  author: string;
  number_of_pages: number;
  publish_date: string;
  language_id?: number | string;
  language_name?: string;
}

export interface languageType {
  language_id?: number;
  language_name: string;
}
