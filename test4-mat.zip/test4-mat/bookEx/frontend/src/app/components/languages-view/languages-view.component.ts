import { Component, OnInit } from '@angular/core';
import { ServerRequestsService } from 'src/app/services/server-requests.service';
import { languageType } from 'src/app/types';

@Component({
  selector: 'app-languages-view',
  templateUrl: './languages-view.component.html',
  styleUrls: ['./languages-view.component.scss']
})
export class LanguagesViewComponent implements OnInit {
  constructor(private ServerRequests: ServerRequestsService) { }

  languageList: languageType[] = [];

  langIdToEdit: number = -1;
  langNewName:string = "";
  isShowAdd = false;

  ngOnInit() {
    this.updateList();
  }

  updateList() {
    this.ServerRequests.getLanguages()
      .subscribe(langList => this.languageList = langList);
  }

  remove(langId: number | undefined) {
    if (langId)
      this.ServerRequests.deleteLanguage(langId)
        .subscribe(res => { console.log(res); this.updateList() });
  }

  edit(langId: number | undefined) {
    if (langId) {
      if (this.langIdToEdit == langId) {
        this.ServerRequests.patchLanguage(langId, this.langNewName)
          .subscribe(res => { console.log(res); this.updateList() });
        this.langIdToEdit = -1;
      }
      else
        this.langIdToEdit = langId;
    }
  }

  showAdd(){
    this.isShowAdd = !this.isShowAdd;
  }
}
