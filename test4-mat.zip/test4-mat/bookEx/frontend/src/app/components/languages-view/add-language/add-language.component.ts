import { Component, EventEmitter, Output } from '@angular/core';
import { ServerRequestsService } from 'src/app/services/server-requests.service';

@Component({
  selector: 'app-add-language',
  templateUrl: './add-language.component.html',
  styleUrls: ['./add-language.component.scss']
})
export class AddLanguageComponent {
  constructor(private ServerRequests: ServerRequestsService) { }

  newLanguage = "";
  @Output() addedLang = new EventEmitter();

  submit() {
    this.ServerRequests.postLanguage(this.newLanguage)
      .subscribe(res => {
        console.log(res);
        this.newLanguage = "";
        this.addedLang.emit();
     });
  }
}
