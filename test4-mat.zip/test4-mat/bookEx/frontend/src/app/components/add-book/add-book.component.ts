import { Component, OnInit, ViewChild } from '@angular/core';
import { ServerRequestsService } from 'src/app/services/server-requests.service';
import { bookType, languageType } from 'src/app/types';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.scss']
})
export class AddBookComponent implements OnInit {
  constructor(private ServerRequests: ServerRequestsService) { }
  @ViewChild("f") form: HTMLFormElement | undefined;

  newBook: bookType = { book_name: "", author: "", number_of_pages: 0, publish_date: "", language_id: "" };

  languages: languageType[] = [];

  ngOnInit() {
    this.ServerRequests.getLanguages()
      .subscribe(langList => this.languages = langList);
  }

  submit() {
    this.ServerRequests.postBook(this.newBook)
      .subscribe(res => {
        console.log(res);
        this.form?.reset();
      });
  }
}
