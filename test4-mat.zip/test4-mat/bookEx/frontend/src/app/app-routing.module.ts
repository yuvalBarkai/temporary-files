import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddBookComponent } from './components/add-book/add-book.component';
import { BooksViewComponent } from './components/books-view/books-view.component';
import { LanguagesViewComponent } from './components/languages-view/languages-view.component';

const routes: Routes = [
  {
    path: "books",
    component: BooksViewComponent
  },
  {
    path: "addbook",
    component: AddBookComponent
  },
  {
    path: "languages",
    component: LanguagesViewComponent
  },
  {
    path: "",
    redirectTo: "books",
    pathMatch: "full"
  },
  {
    path: "**",
    redirectTo: "books",
    pathMatch: "full"
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
