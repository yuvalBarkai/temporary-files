<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>Thanks for sending the form</h2>
        <a href="index.php">HOME</a>
        <?php
//        $name = $_POST["name"];
//        $age = $_POST["age"];
        $name = filter_input(INPUT_POST, "name");
        $age = filter_input(INPUT_POST, "age");

        if (!isset($name) || !isset($age)) {
            $name = "Unknown";
            $age = "Unknown";
        } else {
            if (preg_match('~[0-9]+~', $name)) {
                $name = "Unknown";
            }
        }

        echo "<br> Name: $name";
        ?>
        <div>
            Age: <?= $age ?>
        </div>
    </body>
</html>
