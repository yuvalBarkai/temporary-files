<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>Form</h2>
        <form method="POST" action="display.php">
            <div>
                name:
                <input type="text" name="name">
            </div>
            <div>
                age:
                <input type="number" name="age">
            </div>
            <button>Submit</button>
        </form>
        <?php 
        ?>
    </body>
</html>
