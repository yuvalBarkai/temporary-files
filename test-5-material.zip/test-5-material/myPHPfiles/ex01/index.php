<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $first = filter_input(INPUT_GET, "firstname");
        $last = filter_input(INPUT_GET, "lastname");
        ?>
        <form>
            <label>First name</label>
            <input name="firstname" value="<?= $first ?>" required>
            <br><br>
            <label>Last name</label>
            <input name="lastname" value="<?= $last ?>"  required>
            <br><br>
            <button>Send</button>
        </form>
    </body>
</html>
