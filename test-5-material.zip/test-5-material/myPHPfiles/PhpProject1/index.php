<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>Table</h2>>
        <style><?php include 'newstyle.scss'; ?></style>
        <?php
        echo "<table>";
        echo "<tr>";
        for ($i = 1; $i <= 3; $i++) {
            echo "<th>" . "Column" . $i . "</th>";
        }
        echo "</tr>";
        for ($c = 1; $c <= 3; $c++) {
            echo "<tr>";
            for ($i = 1; $i <= 3; $i++) {
                echo "<td>" . $i . "</td>";
            }
            echo "</tr>";
        }
        echo " </table>";
        ?>
    </body>
</html>
