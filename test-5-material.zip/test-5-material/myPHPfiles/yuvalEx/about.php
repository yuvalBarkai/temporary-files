<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <a href="index.php">HOME</a>
        <h2>About</h2>
        <div>lajsbaks;jdbas jasbd kjasbd kjasbd jhabsd asjkdb a</div>
        <?php
        // put your code here
        ?>
    </body>
</html>
