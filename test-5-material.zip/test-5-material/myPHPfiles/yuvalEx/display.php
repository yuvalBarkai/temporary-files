<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <a href="index.php">HOME</a>
        <h2>Display</h2>
        <?php
        $name = filter_input(INPUT_POST, "name");
        $age = filter_input(INPUT_POST, "age");
        if (empty($name) || empty($age)) {
            echo "<h4> Please log in before entering this page</h4>";
        }
        else{
            echo "<div> Hi $name <br> you are $age years old</div>";
        }
        ?>
    </body>
</html>
