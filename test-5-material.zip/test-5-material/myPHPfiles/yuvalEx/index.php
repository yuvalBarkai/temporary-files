<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <a href="about.php">About</a>
        <a href="display.php">Display</a>
        <form method="post" action="display.php">
            <h2>Login</h2>
            <div>
                Name: 
                <input name="name" placeholder="enter name">
            </div>
            <div>
                Age: 
                <input name="age" placeholder="enter age">
            </div>
            <button>login</button>
        </form>
        <?php
        
        ?>
    </body>
</html>
