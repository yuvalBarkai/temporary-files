<!DOCTYPE html
    <html>
<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>
    <h1>My Website</h1>
    <?php
    $test = 50;
    $list = array(10, 90, 300, 650);
    $obj = new stdClass();
    $obj->age = 30;
    $obj->name = "menahem";
    $print = "";
    foreach($list as $i){
        if($i > 100)
            $print .= "<li> $i";
        else
            $print .= "<li> small";
    }
    require_once './util.php';

//    show("ONE");
//    show("TWO");
//    show("FIFTHY");
//    
//    $items = array("sky" => "blue", "sun" => "yellow", "wine" => "red");
//    $items["sun"] = "orange";
//    foreach ($items as $key => $value) {
//        show($key . " : " . $value);
//    }
    ?>
    <div>
        <h2>אינטרפולציה ל HTML</h2>
        <?= $print ?>
    </div>
</body>
</html>
