<?php

function show($message) {
    echo $message . "<br>";
}
