<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <style><?php include 'newstyle.scss'; ?></style>
        <?php
        echo "<table> <tr>";
        for ($i = 1; $i <= 3; $i++) {
            echo '<th>' . "Column" . $i, "</th>";
        }
        echo "</tr>";
        $display = 1;
        for ($i = 1; $i <= 3; $i++) {
            echo "<tr>";
            for ($t = 1; $t <= 3; $t++) {
                echo "<td>" . $display . "</td>";
                $display++;
            }
            echo "</tr>";
        }
        echo "</table>";
        ?>
    </body>
</html>
