<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>div{ margin: 5px }</style>
    </head>
    <body>
        <form action='result.php' method="post">
            <h2>Calculator</h2>
            <div>
                First: 
                <input name="first">
            </div>
            <div>
                <select name="operator">
                    <option value=''>select an operator</option>
                    <option value='0'>+</option>
                    <option value='1'>-</option>
                    <option value='2'>*</option>
                    <option value='3'>/</option>
                </select>
            </div>
            <div>
                Second:  
                <input name="second">
            </div>
            
            <button>Calc</button>
        </form>
    </body>
</html>
