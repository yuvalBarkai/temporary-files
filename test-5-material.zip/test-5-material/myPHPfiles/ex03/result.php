<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $first = filter_input(INPUT_POST, "first");
        $second = filter_input(INPUT_POST, "second");
        $operator = filter_input(INPUT_POST, "operator");
        $operators = array("+", "-", "*", "/");
        $chosenOperator = $operators[$operator];

        
//        if ($operator == 0) {
//            $result = $first + $second;
//        } else if ($operator == 1) {
//            $result = $first - $second;
//        } else if ($operator == 2) {
//            $result = $first * $second;
//        } else if ($operator == 3) {
//            $result = $first / $second;
//        }
        ?>
        <h2>Result</h2>
        <div><?= $first ?> <?= $chosenOperator ?> <?= $second ?> = <?= $result ?></div>
    </body>
</html>
