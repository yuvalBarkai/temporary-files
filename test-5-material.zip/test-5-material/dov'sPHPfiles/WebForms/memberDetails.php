<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Member Details</h1>
        <?php
            $firstname=$_POST["firstname"];
            $lastname=$_POST["lastname"];
            
            echo "Name: $firstname, Last name: $lastname";
        ?>
    </body>
</html>
