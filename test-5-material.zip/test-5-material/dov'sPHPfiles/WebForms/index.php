<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Member Form</h1>
        
        <form method="post" action="memberDetails.php">
            <label>First name</label>
            <input name="firstname" required>
            <br><br>
            <label>Last name</label>
            <input name="lastname" required>
            <br><br>
            <button>Send</button>
        </form>
        <?php
        // put your code here
        ?>
    </body>
</html>
