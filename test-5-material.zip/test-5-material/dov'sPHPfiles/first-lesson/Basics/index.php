<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>PHP Programming Model</h1>
        <?php
            // Variables and Assignment
            $a=50;
            $b=30;
            $c=$a+$b;
            echo "a=" . $a . "<br>";
            echo "b=" . $b . "<br>";
            echo "a=$a b=$b c=$c";
            echo "<br>a=$" . "\$a<br>";
        
            // if
            if ($a>50) {
                echo "Result is greater than 50";
            }
            else {
                echo "Result is perfect!<br>";
            }
            
            
            // Switch case
            
            $choice=1;
            
            switch($choice) {
                case 1:
                    echo "Choice=1<br>";
                    break;
                case 2:
                    echo "Choice=2<br>";
                    break;
                default:
                    echo "Default Choice<br>";
            }
            
            // while
            
            $i=8;
            while ($i>0) {
                echo "$i<br>";
                $i--;
            }
            
            echo "==============<br>";
            
            // Do while
            
            $i=8;
            do {
                echo "$i<br>";
                $i--;
            } while ($i>0);
            
            //Object
            
            $student=new stdClass();
            $student->age=23;
            $student->name="Yosi";
            
            echo "$student->name";
            
            $a+=20;
            
            
        ?>
    </body>
</html>
