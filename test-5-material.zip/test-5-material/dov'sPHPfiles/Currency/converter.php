<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $amount=$_GET["amount"];
            $currencyIndex=$_GET["currencyIndex"];
            
            $rates=array(3.22, 3.73, 0.045);
            $names=array("Dollar", "Euro", "Ruble");
            
            $result=$amount*$rates[$currencyIndex];
        ?>
        <h1> ... To Shekel</h1>
        <h2><?=$amount  ?>  <?=$names[$currencyIndex] ?> = <?=$result ?></h2>
    </body>
</html>
