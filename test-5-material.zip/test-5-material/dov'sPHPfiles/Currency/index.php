<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>Currency</h1>
        
        <form method="post">
            <label>Amount of money</label>
            <input name="amount" required>
            <br><br>
            <label>Currency</label>
            <select name="currencyIndex" required>
                <option value="">Select</option>
                <option value="0">Dollar</option>
                <option value="1">Euro</option>
                <option value="2">Ruble</option>
            </select>
            <br><br>
            <button>Send</button>
                
        </form>
        <?php
            if ($_SERVER["REQUEST_METHOD"]==="POST") {
                if(isset($_POST["amount"]) && isset($_POST["currencyIndex"])) {
                    header("Location: converter.php?amount="
                            . $_POST["amount"] . "&currencyIndex="
                            . $_POST["currencyIndex"]
                            );
                }
            }
        ?>
    </body>
</html>
