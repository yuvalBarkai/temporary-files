<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>PHP Programming Model</h1>
        <?php
            // Variables and Assignment
            $a=50;
            $b=30;
            $c=$a+$b;
            echo "a=" . $a . "<br>";
            echo "b=" . $b . "<br>";
            echo "a=$a b=$b c=$c";
            echo "<br>a=$" . "\$a<br>";
        
            // if
            if ($a>50) {
                echo "Result is greater than 50";
            }
            else {
                echo "Result is perfect!<br>";
            }
            
            
            // Switch case
            
            $choice=1;
            
            switch($choice) {
                case 1:
                    echo "Choice=1<br>";
                    break;
                case 2:
                    echo "Choice=2<br>";
                    break;
                default:
                    echo "Default Choice<br>";
            }
            
            // while
            
            $i=8;
            while ($i>0) {
                echo "$i<br>";
                $i--;
            }
            
            echo "==============<br>";
            
            // Do while
            
            $i=8;
            do {
                echo "$i<br>";
                $i--;
            } while ($i>0);
            
            //Object
            
            $student=new stdClass();
            $student->age=23;
            $student->name="Yosi";
            
            echo "$student->name";
            
            $a+=20;
            
            // Array
            
            echo "<h2>Array</h2>";
            
            $numbers=array(54,87,12,57,2,3);
            echo $numbers[1];
            
            echo "<br>";
            
            echo count($numbers);
            echo "<br>";echo "<br>";
            
            // for loop
            for ($i=0; $i<count($numbers) ; $i++)
                echo "$numbers[$i]<br>";
            
            echo "<br>";echo "<br>";
            
            // for each
            
            echo "foreach<br>";
            foreach($numbers as $x) {
                echo "$x<br>";
            }
            
            echo "<br>";echo "<br>";
            
            // function
            
            function show($message) {
                echo "$message<br>";
            }
            
            show("My first php function<br>");
            
            echo "<br>";echo "<br>";
            
            echo "Max of 50 and 60 is " . getMax1(50,60);
            
            function getMax($a, $b) {
                if ($a>$b)
                    return $a;
                return $b;
            }
            
            function getMax1($a, $b) {
                if ($a>$b) {
                    $c=$a;
                }
                else {
                    $c=$b;
                }
                return $c;
            }
            
            require_once 'util.php';
            
            echo "<br>";echo "<br>";
            
            echo "Min of 50 and 60 is " . getMin(50,60);
            echo "<br>";echo "<br>";
            
            $items=array("sky" => "blue", "sun" => "yellow", "wine" => "red");
            foreach($items as $key => $value) {
                echo "$key is $value<br>";
            }
            echo "<br>";echo "<br>";
            
            echo "The sun is " . $items["sun"];
        ?>
    </body>
</html>
