<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Project/PHP/PHPProject.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>The Table</h1>
        <?php
            $tb="<table border='1'>";
            $tb = $tb . "<thead><th>Column 1</th><th>Column 2</th><th>Column3</th></thead>";
            $tb = $tb . "<tbody style='text-align:center'>";
            $tb=$tb . "<tr><td>1</td><td>2</td><td>3</td></tr>";
            $tb=$tb . "<tr><td>1</td><td>2</td><td>3</td></tr>";
            $tb=$tb . "<tr><td>1</td><td>2</td><td>3</td></tr>";
            $tb=$tb . "</tbody></table";
            echo("$tb");
        ?>
    </body>
</html>
