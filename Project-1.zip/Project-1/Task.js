class Task{
    constructor(taskDetails, dueDate, dueTime){
        this.taskDetails = taskDetails;
        this.dueDate = dueDate;
        this.dueTime = dueTime;
    }
}