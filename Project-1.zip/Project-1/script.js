const taskDetailsInput = document.getElementById("taskDetailsInput");
const dueDateInput = document.getElementById("dueDate");
const dueTimeInput = document.getElementById("dueTime");
const taskBoard = document.getElementById("taskBoard");
const errorMsg = document.getElementById("errorMsg");


let taskList = [];
if(localStorage.taskListMemory)
    taskList = JSON.parse(localStorage.taskListMemory);

showTasks();
taskDetailsInput.focus();

function addTask(){
    errorMsg.innerText = "";

    const userDate = new Date(dueDateInput.value); 
    const currentTime = new Date();
    userDate.setHours(dueTimeInput.value.substring(0,2),dueTimeInput.value.substring(3,5),0,0);
    
    if(userDate<currentTime)
        errorMsg.innerText = "The Date you entered is in the past";

    else{ // The task is added and printed
        taskList.push(new Task(taskDetailsInput.value, dueDateInput.value.split("-").reverse().join("/"), dueTimeInput.value));
        localStorage.taskListMemory = JSON.stringify(taskList);

        taskDetailsInput.value = "";
        dueDateInput.value = "";
        dueTimeInput.value = "";
        showTasks(taskList.length-1);
    }
    taskDetailsInput.focus();
}

function showTasks(specific){
    if(specific>=0){ // show specific task by index with a fade if an argument was placed
        const taskDiv = document.createElement("div");
        const detailsOutput = document.createElement("div");
        const dueDateOutput = document.createElement("div");
        const deleteButton = document.createElement("button");

        detailsOutput.innerText = taskList[specific].taskDetails;
        detailsOutput.setAttribute("class","taskDetailsOutput");
        
        dueDateOutput.innerText = `${taskList[specific].dueDate} \n ${taskList[specific].dueTime}`;
        dueDateOutput.setAttribute("class","taskDueDateOutput");

        deleteButton.innerText = "X";
        deleteButton.setAttribute("class",`btn-close`);
        deleteButton.setAttribute("onclick",`deleteTask(${specific})`);
        
        taskDiv.setAttribute("class","task newTask");
        taskDiv.append(deleteButton, detailsOutput,dueDateOutput);
        taskBoard.appendChild(taskDiv);
    }
    else { // show all tasks
        taskBoard.innerText = "";
        for(let t in taskList){
            const taskDiv = document.createElement("div");
            const detailsOutput = document.createElement("div");
            const dueDateOutput = document.createElement("div");
            const deleteButton = document.createElement("button");
        
            detailsOutput.innerText = taskList[t].taskDetails;
            detailsOutput.setAttribute("class","taskDetailsOutput");

            dueDateOutput.innerText = `${taskList[t].dueDate} \n ${taskList[t].dueTime}`;
            dueDateOutput.setAttribute("class","taskDueDateOutput");

            deleteButton.innerText = "X";
            deleteButton.setAttribute("class",`btn-close`);
            deleteButton.setAttribute("onclick",`deleteTask(${t})`);

            taskDiv.setAttribute("class","task");
            taskDiv.append(deleteButton, detailsOutput,dueDateOutput);
            taskBoard.appendChild(taskDiv);
        }
    }
}

function deleteTask(index){
    taskList.splice(index,1);
    localStorage.taskListMemory = JSON.stringify(taskList);
    showTasks();
}