class movieTemplate {
    constructor(public name:string, public rating:number, public catagory:string){}
}

export default movieTemplate