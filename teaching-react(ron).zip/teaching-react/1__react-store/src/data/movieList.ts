import movieTemplate from "./movieTemplate"

const movieList = [
    new movieTemplate("forest", 5, "drama"),
    new movieTemplate("asdasd", 2, "asdasd"),
    new movieTemplate("bfdjkgf", 4, "ngh"),
    new movieTemplate("שדשדגשדג", 1, "דגחלשד"),
    new movieTemplate("sadjhasd", 5, "שדגשדג"),
]

export default movieList