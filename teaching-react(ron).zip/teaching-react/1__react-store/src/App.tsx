import './App.css';
import Movie from './components/Movie';
import movieList from "./data/movieList";

function App() {
    return (
        <div className="App">
            <h1>React Template</h1>
            {movieList.map((m)=> <Movie name={m.name} rating={m.rating} catagory={m.catagory} /> )}
        </div>
    );
}

export default App;