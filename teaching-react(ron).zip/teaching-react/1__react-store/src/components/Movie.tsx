interface movieProps {
    name:string;
    rating:number;
    catagory:string;
}

function Movie(props:movieProps){

    return(
        <div>
            <h2>Name: {props.name}</h2>
            <div>Rating: {props.rating}/5</div>
            <div>catagory: {props.catagory}</div>
        </div>
    )
}

export default Movie