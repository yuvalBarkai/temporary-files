import bookTemplate from "./bookTemplate";

const bookList = [
    new bookTemplate("The Adventures of Sherlock Holmes", "https://upload.wikimedia.org/wikipedia/commons/b/b9/Adventures_of_sherlock_holmes.jpg", "Arthur Conan Doyle", 50),
    new bookTemplate("The Hitchhiker's Guide to the Galaxy", "https://images.penguinrandomhouse.com/cover/9781400052929","Dougles Adams",40),
];

export default bookList