class bookTemplate {
    constructor(public name: string, public img:string, public author: string, public price: number) {}
}

export default bookTemplate