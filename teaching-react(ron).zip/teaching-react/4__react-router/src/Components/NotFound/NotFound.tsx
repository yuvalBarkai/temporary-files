function NotFound() {
    return (
        <div className="component">
            <h2>NotFound</h2>
            <div className="text text-danger">
                Sorry, we couldnt find your page try another address
            </div>
        </div>
    )
}

export default NotFound