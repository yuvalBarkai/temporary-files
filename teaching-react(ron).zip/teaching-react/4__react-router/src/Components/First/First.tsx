function First() {
    return (
        <div className="component">
            <h2>First</h2>
            <div>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quos iusto dicta commodi consectetur illo fuga atque voluptatibus itaque magnam! Tenetur.
            </div>
        </div>
    )
}

export default First