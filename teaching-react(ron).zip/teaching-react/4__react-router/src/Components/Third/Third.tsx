
function Third() {
    return (
        <div className="component">
            <h2>Third</h2>
            <div>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci reiciendis dicta voluptatibus officia in repellat consequuntur qui quia esse quam ullam, distinctio voluptate repudiandae velit quos optio sed illo accusantium!
            </div>
        </div>
    )
}

export default Third