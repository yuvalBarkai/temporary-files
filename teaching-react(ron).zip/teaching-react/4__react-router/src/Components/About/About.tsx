function About() {
    return (
        <div className="component">
            <h2>About</h2>
            <div>
                Lorem ipsum dolor sit, amet consectetur adipisicing elit. Corrupti dolorum fuga, accusantium consectetur tenetur architecto.
            </div>
        </div>
    )
}

export default About