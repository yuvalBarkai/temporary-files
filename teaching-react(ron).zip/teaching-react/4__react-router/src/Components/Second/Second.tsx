
function Second() {
    return (
        <div className="component">
            <h2>Second</h2>
            <div>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eius, modi.
                lorem5000
            </div>
        </div>
    )
}

export default Second