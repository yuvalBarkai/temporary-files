
function Sherlock(){
    return(
        <div className="book">
            <h2 className="name"> Sherlock Holmes </h2>            
            <div className="author">Arthur Conan Doyle</div>
            <footer className="price"> Price: 50$</footer>
        </div>
    )
}

export default Sherlock