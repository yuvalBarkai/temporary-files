
function Mossad() {
    return (
        <div className="book">
            <h2 className="name"> Mossad </h2>
            <div className="author">Nissim mishal</div>
            <footer className="price"> Price: 118$</footer>
        </div>
    )
}

export default Mossad