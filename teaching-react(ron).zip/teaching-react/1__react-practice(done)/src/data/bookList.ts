import bookTemplate from "./bookTemplate";

const bookList = [
    new bookTemplate("Mossad", "nissim", 118),
    new bookTemplate("sherlock", "nissim", 50),
    new bookTemplate("asdsad", "asda", 4),
    new bookTemplate("3231", "asd", 50),
    new bookTemplate("vvknjjb", "asdjhbv", 160),
    new bookTemplate("asdasdas", "sadasd", 5000),
    new bookTemplate("23232", "asdasd", 900),
    new bookTemplate("shabak", "baruch", 50),
];

export default bookList