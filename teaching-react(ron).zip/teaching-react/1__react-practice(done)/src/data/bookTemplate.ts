class bookTemplate {
    constructor(public name: string, public author: string, public price: number) {}
}

export default bookTemplate